﻿using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text.RegularExpressions;

namespace C8
{
    public static class Program4
    {
        public static IEnumerable<TSource> Where<TSource> (this IEnumerable<TSource> source, Func<TSource, bool> predicate)
        {
            foreach (TSource element in source)
                if (predicate(element))
                    yield return element;
        }

        public static Func<int, int> sum(int x)
        {
            Func<int, int> sum2 = y => y + x;
            return sum2;
        }

        public static Func<T1, Func<T2, TResult>> Curry<T1, T2, TResult>
            (Func<T1, T2, TResult> function)
        {
            return a => b => function(a, b);
        }

        public static T power<T>(T number, int exponent, Func<T, T, T> function)
        {
            int remainingEvenExp = exponent/2;
            int remainingOddExp = exponent%2;
            T square = function.Invoke(number, number);
            T result = square;
            if (remainingEvenExp != 1) {
                result = power<T>(square, remainingEvenExp, function);
            } else if (remainingOddExp != 0) {
                result = function.Invoke(result, number); ;
            }
            return result;
        }

        public static void NorvigSpellChecker(string word)
        {
            var alphabets = @"abcdefghijklmnopqrstuvwxyz";
            var WORDS = new ConcurrentDictionary<string, int>();
            var trainingFile = @"D:\Packt\Code\NSC_Training_Model.txt";
            var P = 0;
            //Stage #1
            var Train = Task.Factory.StartNew(() =>
            {
                foreach(var line in File.ReadLines(trainingFile)
                    .AsParallel())
                {
                    foreach (Match match in Regex.Matches(line, @"([a-z]+)", RegexOptions.IgnoreCase)
                        .AsParallel())
                        {
                            WORDS.AddOrUpdate(match.Value, 0, (k, v) => v + 1);
                        }
                }
            });
            var Probability = Task.Factory.StartNew(() =>
            {
                var N = (from x in WORDS.AsParallel()
                        select x.Value).Sum();
                int f = 0;
                if (WORDS.TryGetValue(word, out f)) {
                    P = f / N;//Probability of Word
                }
            });
            var edits1 = Task.Factory.StartNew(() =>
                {
                    return from i in Enumerable.Range(0, word.Length).AsParallel()
                        select new {a = word.Substring(0, i), b = word.Substring(i)};
                });
            /*edits1.ContinueWith(ant =>
                {
                    return (from s in ant.Result
                            where s.b != ""
                            select s.a + s.b.Substring(1))//deletes
                            .Union(from s in ant.Result
                            where s.b.Length > 1
                            select s.a + s.b[1] + s.b[0] + s.b.Substring(2))//transposes
                            .Union(from s in ant.Result
                            from c in alphabets
                            where s.b != ""
                            select s.a + c + s.b.Substring(1))//replaces
                            .Union(from s in ant.Result
                            from c in alphabets
                            select s.a + c + s.b);//inserts
                });*/
            Task.WaitAll(Train);
            Task.WaitAll(Probability);
            Task.WaitAll(edits1);
            foreach(var edit1 in edits1.Result)
            {
                Console.WriteLine(edit1);
            }
            Console.WriteLine("Training Model Creation Complete! {0}", P);
        }
    }
}
