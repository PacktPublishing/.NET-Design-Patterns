﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C8
{
    class Start
    {
        static void Main(string[] args)
        {
            Program1.AdaptivePower(args);
            //Program4.NorvigSpellChecker("shine");
            Console.ReadLine();
        }
    }
}
